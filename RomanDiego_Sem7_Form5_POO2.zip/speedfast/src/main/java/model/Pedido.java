package model;

public abstract class Pedido {
    private int id;
    private String direccion;
    private EstadoPedido estado;

    public Pedido(String direccion, EstadoPedido estado) {
        this.direccion = direccion;
        this.estado = estado;
    }

    /** Devuelve COMIDA, ENCOMIENDA o EXPRESS (el valor que se guarda en la columna tipo). */
    public abstract String getTipo();

    public abstract int calcularTiempoEntrega();

    /** Crea la subclase correcta según el tipo leído desde la base de datos o el formulario. */
    public static Pedido crear(String tipo, String direccion, EstadoPedido estado) {
        switch (tipo) {
            case "COMIDA":     return new PedidoComida(direccion, estado);
            case "ENCOMIENDA": return new PedidoEncomienda(direccion, estado);
            case "EXPRESS":    return new PedidoExpress(direccion, estado);
            default: throw new IllegalArgumentException("Tipo de pedido no válido: " + tipo);
        }
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
    public EstadoPedido getEstado() { return estado; }
    public void setEstado(EstadoPedido estado) { this.estado = estado; }

    @Override
    public String toString() {
        return "#" + id + " - " + direccion + " (" + getTipo() + ")";
    }
}
