package model;

public class PedidoExpress extends Pedido {

    public PedidoExpress(String direccion, EstadoPedido estado) {
        super(direccion, estado);
    }

    @Override
    public String getTipo() {
        return "EXPRESS";
    }

    @Override
    public int calcularTiempoEntrega() {
        return 20; // minutos
    }
}
