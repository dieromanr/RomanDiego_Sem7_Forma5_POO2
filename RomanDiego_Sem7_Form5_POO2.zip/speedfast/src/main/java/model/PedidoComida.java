package model;

public class PedidoComida extends Pedido {

    public PedidoComida(String direccion, EstadoPedido estado) {
        super(direccion, estado);
    }

    @Override
    public String getTipo() {
        return "COMIDA";
    }

    @Override
    public int calcularTiempoEntrega() {
        return 45; // minutos
    }
}
