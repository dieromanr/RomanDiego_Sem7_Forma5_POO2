package model;

public class PedidoEncomienda extends Pedido {

    public PedidoEncomienda(String direccion, EstadoPedido estado) {
        super(direccion, estado);
    }

    @Override
    public String getTipo() {
        return "ENCOMIENDA";
    }

    @Override
    public int calcularTiempoEntrega() {
        return 60; // minutos
    }
}
