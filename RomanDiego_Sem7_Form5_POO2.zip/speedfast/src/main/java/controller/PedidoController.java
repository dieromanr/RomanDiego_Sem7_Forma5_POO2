package controller;

import dao.EntregaDAO;
import dao.PedidoDAO;
import dao.RepartidorDAO;
import model.Entrega;
import model.EstadoPedido;
import model.Pedido;
import model.Repartidor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/** Controlador compartido por todas las ventanas: conecta la interfaz con los DAO. */
public class PedidoController {
    private final PedidoDAO pedidoDAO = new PedidoDAO();
    private final RepartidorDAO repartidorDAO = new RepartidorDAO();
    private final EntregaDAO entregaDAO = new EntregaDAO();

    public boolean registrarPedido(String tipo, String direccion) {
        Pedido pedido = Pedido.crear(tipo, direccion, EstadoPedido.PENDIENTE);
        return pedidoDAO.guardar(pedido);
    }

    public List<Pedido> listarPedidos() {
        return pedidoDAO.listarTodos();
    }

    public List<Pedido> listarPedidosPendientes() {
        List<Pedido> pendientes = new ArrayList<>();
        for (Pedido p : pedidoDAO.listarTodos()) {
            if (p.getEstado() == EstadoPedido.PENDIENTE) {
                pendientes.add(p);
            }
        }
        return pendientes;
    }

    public boolean registrarRepartidor(String nombre) {
        return repartidorDAO.guardar(new Repartidor(nombre));
    }

    public List<Repartidor> listarRepartidores() {
        return repartidorDAO.listarTodos();
    }

    /** Registra la entrega (fecha y hora actuales) y deja el pedido EN_REPARTO. */
    public boolean registrarEntrega(Pedido pedido, Repartidor repartidor) {
        Entrega entrega = new Entrega(pedido.getId(), repartidor.getId(),
                LocalDate.now(), LocalTime.now().withNano(0));
        boolean ok = entregaDAO.guardar(entrega);
        if (ok) {
            pedidoDAO.actualizarEstado(pedido.getId(), EstadoPedido.EN_REPARTO);
        }
        return ok;
    }
}
