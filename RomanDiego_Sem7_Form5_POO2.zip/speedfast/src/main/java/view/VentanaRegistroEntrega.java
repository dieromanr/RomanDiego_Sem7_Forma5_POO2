package view;

import controller.PedidoController;
import model.Pedido;
import model.Repartidor;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.GridLayout;

public class VentanaRegistroEntrega extends JFrame {
    private final PedidoController controller;
    private final JComboBox<Pedido> cmbPedidos = new JComboBox<>();
    private final JComboBox<Repartidor> cmbRepartidores = new JComboBox<>();

    public VentanaRegistroEntrega(PedidoController controller) {
        super("Asignar entrega");
        this.controller = controller;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(450, 220);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(0, 2, 10, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(new JLabel("Pedido pendiente:"));
        panel.add(cmbPedidos);
        panel.add(new JLabel("Repartidor:"));
        panel.add(cmbRepartidores);

        JButton btnAsignar = new JButton("Asignar");
        JButton btnCancelar = new JButton("Cancelar");
        panel.add(btnAsignar);
        panel.add(btnCancelar);

        btnAsignar.addActionListener(e -> asignar());
        btnCancelar.addActionListener(e -> dispose());

        add(panel);
        cargarCombos();
    }

    private void cargarCombos() {
        cmbPedidos.removeAllItems();
        cmbRepartidores.removeAllItems();
        for (Pedido p : controller.listarPedidosPendientes()) {
            cmbPedidos.addItem(p);
        }
        for (Repartidor r : controller.listarRepartidores()) {
            cmbRepartidores.addItem(r);
        }
    }

    private void asignar() {
        Pedido pedido = (Pedido) cmbPedidos.getSelectedItem();
        Repartidor repartidor = (Repartidor) cmbRepartidores.getSelectedItem();
        if (pedido == null || repartidor == null) {
            JOptionPane.showMessageDialog(this,
                    "Necesitas al menos un pedido pendiente y un repartidor registrado.",
                    "Datos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (controller.registrarEntrega(pedido, repartidor)) {
            JOptionPane.showMessageDialog(this, "Entrega registrada. El pedido quedó EN_REPARTO.");
            cargarCombos();
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo registrar la entrega.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
