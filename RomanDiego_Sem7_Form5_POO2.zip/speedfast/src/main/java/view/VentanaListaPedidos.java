package view;

import controller.PedidoController;
import model.Pedido;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;

public class VentanaListaPedidos extends JFrame {
    private final PedidoController controller;
    private final DefaultTableModel modelo =
            new DefaultTableModel(new Object[]{"ID", "Dirección", "Tipo", "Estado"}, 0) {
                @Override
                public boolean isCellEditable(int fila, int columna) {
                    return false;
                }
            };

    public VentanaListaPedidos(PedidoController controller) {
        super("Pedidos registrados");
        this.controller = controller;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(600, 380);
        setLocationRelativeTo(null);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(e -> cargarTabla());
        JPanel abajo = new JPanel();
        abajo.add(btnActualizar);

        add(new JScrollPane(new JTable(modelo)), BorderLayout.CENTER);
        add(abajo, BorderLayout.SOUTH);
        cargarTabla();
    }

    private void cargarTabla() {
        modelo.setRowCount(0);
        for (Pedido p : controller.listarPedidos()) {
            modelo.addRow(new Object[]{p.getId(), p.getDireccion(), p.getTipo(), p.getEstado()});
        }
    }
}
