package view;

import controller.PedidoController;
import model.Repartidor;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

public class VentanaRegistroRepartidor extends JFrame {
    private final PedidoController controller;
    private final JTextField txtNombre = new JTextField(18);
    private final DefaultTableModel modelo =
            new DefaultTableModel(new Object[]{"ID", "Nombre"}, 0) {
                @Override
                public boolean isCellEditable(int fila, int columna) {
                    return false;
                }
            };

    public VentanaRegistroRepartidor(PedidoController controller) {
        super("Registrar repartidor");
        this.controller = controller;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(420, 360);
        setLocationRelativeTo(null);

        JPanel formulario = new JPanel(new FlowLayout());
        formulario.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
        formulario.add(new JLabel("Nombre:"));
        formulario.add(txtNombre);
        JButton btnGuardar = new JButton("Guardar");
        formulario.add(btnGuardar);

        btnGuardar.addActionListener(e -> {
            String nombre = txtNombre.getText().trim();
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingresa el nombre del repartidor.",
                        "Datos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (controller.registrarRepartidor(nombre)) {
                txtNombre.setText("");
                cargarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo guardar el repartidor.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        add(formulario, BorderLayout.NORTH);
        add(new JScrollPane(new JTable(modelo)), BorderLayout.CENTER);
        cargarTabla();
    }

    private void cargarTabla() {
        modelo.setRowCount(0);
        for (Repartidor r : controller.listarRepartidores()) {
            modelo.addRow(new Object[]{r.getId(), r.getNombre()});
        }
    }
}
