package view;

import controller.PedidoController;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.GridLayout;

public class VentanaPrincipal extends JFrame {

    public VentanaPrincipal(PedidoController controller) {
        super("SpeedFast - Gestión de pedidos");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(380, 340);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(0, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JLabel titulo = new JLabel("SpeedFast", SwingConstants.CENTER);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 22f));
        panel.add(titulo);

        panel.add(crearBoton("Registrar pedido",
                () -> new VentanaRegistroPedido(controller).setVisible(true)));
        panel.add(crearBoton("Registrar repartidor",
                () -> new VentanaRegistroRepartidor(controller).setVisible(true)));
        panel.add(crearBoton("Asignar entrega",
                () -> new VentanaRegistroEntrega(controller).setVisible(true)));
        panel.add(crearBoton("Ver pedidos",
                () -> new VentanaListaPedidos(controller).setVisible(true)));

        add(panel);
    }

    private JButton crearBoton(String texto, Runnable accion) {
        JButton boton = new JButton(texto);
        boton.addActionListener(e -> accion.run());
        return boton;
    }
}
