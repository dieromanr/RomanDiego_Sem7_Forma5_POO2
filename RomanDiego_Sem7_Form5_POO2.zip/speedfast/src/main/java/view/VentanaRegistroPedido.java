package view;

import controller.PedidoController;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.GridLayout;

public class VentanaRegistroPedido extends JFrame {
    private final JComboBox<String> cmbTipo =
            new JComboBox<>(new String[]{"COMIDA", "ENCOMIENDA", "EXPRESS"});
    private final JTextField txtDireccion = new JTextField();

    public VentanaRegistroPedido(PedidoController controller) {
        super("Registrar pedido");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(400, 220);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(0, 2, 10, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Tipo de pedido:"));
        panel.add(cmbTipo);
        panel.add(new JLabel("Dirección:"));
        panel.add(txtDireccion);

        JButton btnGuardar = new JButton("Guardar");
        JButton btnCancelar = new JButton("Cancelar");
        panel.add(btnGuardar);
        panel.add(btnCancelar);

        btnGuardar.addActionListener(e -> {
            String direccion = txtDireccion.getText().trim();
            if (direccion.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingresa una dirección.",
                        "Datos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (controller.registrarPedido((String) cmbTipo.getSelectedItem(), direccion)) {
                JOptionPane.showMessageDialog(this, "Pedido registrado correctamente.");
                txtDireccion.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo guardar el pedido.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        btnCancelar.addActionListener(e -> dispose());

        add(panel);
    }
}
