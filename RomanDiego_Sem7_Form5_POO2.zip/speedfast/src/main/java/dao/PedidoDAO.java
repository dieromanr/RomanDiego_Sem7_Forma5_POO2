package dao;

import model.EstadoPedido;
import model.Pedido;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    public boolean guardar(Pedido pedido) {
        String sql = "INSERT INTO pedido (direccion, tipo, estado) VALUES (?, ?, ?)";
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet claves = null;
        try {
            con = ConexionDB.conectar();
            ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, pedido.getDireccion());
            ps.setString(2, pedido.getTipo());
            ps.setString(3, pedido.getEstado().name());
            int filas = ps.executeUpdate();
            claves = ps.getGeneratedKeys();
            if (claves.next()) {
                pedido.setId(claves.getInt(1));
            }
            return filas > 0;
        } catch (SQLException e) {
            System.err.println("Error al guardar pedido: " + e.getMessage());
            return false;
        } finally {
            ConexionDB.cerrar(claves, ps, con);
        }
    }

    public List<Pedido> listarTodos() {
        String sql = "SELECT id, direccion, tipo, estado FROM pedido ORDER BY id";
        List<Pedido> pedidos = new ArrayList<>();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            con = ConexionDB.conectar();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Pedido p = Pedido.crear(rs.getString("tipo"), rs.getString("direccion"),
                        EstadoPedido.valueOf(rs.getString("estado")));
                p.setId(rs.getInt("id"));
                pedidos.add(p);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar pedidos: " + e.getMessage());
        } finally {
            ConexionDB.cerrar(rs, ps, con);
        }
        return pedidos;
    }

    public boolean actualizarEstado(int idPedido, EstadoPedido nuevoEstado) {
        String sql = "UPDATE pedido SET estado = ? WHERE id = ?";
        Connection con = null;
        PreparedStatement ps = null;
        try {
            con = ConexionDB.conectar();
            ps = con.prepareStatement(sql);
            ps.setString(1, nuevoEstado.name());
            ps.setInt(2, idPedido);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar estado: " + e.getMessage());
            return false;
        } finally {
            ConexionDB.cerrar(ps, con);
        }
    }
}
