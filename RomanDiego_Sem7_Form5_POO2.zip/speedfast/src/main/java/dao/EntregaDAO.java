package dao;

import model.Entrega;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;

public class EntregaDAO {

    /** Registra la relación entre un pedido y un repartidor. */
    public boolean guardar(Entrega entrega) {
        String sql = "INSERT INTO entrega (id_pedido, id_repartidor, fecha, hora) VALUES (?, ?, ?, ?)";
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet claves = null;
        try {
            con = ConexionDB.conectar();
            ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, entrega.getIdPedido());
            ps.setInt(2, entrega.getIdRepartidor());
            ps.setDate(3, Date.valueOf(entrega.getFecha()));
            ps.setTime(4, Time.valueOf(entrega.getHora()));
            int filas = ps.executeUpdate();
            claves = ps.getGeneratedKeys();
            if (claves.next()) {
                entrega.setId(claves.getInt(1));
            }
            return filas > 0;
        } catch (SQLException e) {
            System.err.println("Error al guardar entrega: " + e.getMessage());
            return false;
        } finally {
            ConexionDB.cerrar(claves, ps, con);
        }
    }
}
