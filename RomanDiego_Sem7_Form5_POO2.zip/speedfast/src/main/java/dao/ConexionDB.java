package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {
    private static final String URL =
            "jdbc:mysql://localhost:3306/speedfast_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "tu_contraseña"; // <-- cambia por tu contraseña de MySQL

    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /** Cierra en silencio cualquier recurso JDBC (ResultSet, Statement, Connection). */
    public static void cerrar(AutoCloseable... recursos) {
        for (AutoCloseable recurso : recursos) {
            if (recurso != null) {
                try {
                    recurso.close();
                } catch (Exception e) {
                    System.err.println("Error al cerrar recurso: " + e.getMessage());
                }
            }
        }
    }

    /** Prueba rápida de conexión, útil al iniciar la aplicación. */
    public static boolean probarConexion() {
        Connection con = null;
        try {
            con = conectar();
            return con != null && !con.isClosed();
        } catch (SQLException e) {
            System.err.println("No se pudo conectar a la base de datos: " + e.getMessage());
            return false;
        } finally {
            cerrar(con);
        }
    }
}
