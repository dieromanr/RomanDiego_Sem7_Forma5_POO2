package main;

import controller.PedidoController;
import dao.ConexionDB;
import view.VentanaPrincipal;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            if (!ConexionDB.probarConexion()) {
                JOptionPane.showMessageDialog(null,
                        "No se pudo conectar a MySQL.\nRevisa usuario, contraseña y que exista la base speedfast_db.",
                        "Error de conexión", JOptionPane.ERROR_MESSAGE);
                return;
            }
            new VentanaPrincipal(new PedidoController()).setVisible(true);
        });
    }
}
